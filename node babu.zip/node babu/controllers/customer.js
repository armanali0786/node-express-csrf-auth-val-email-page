const bcrypt = require('bcrypt');
const crypto = require('crypto');

const nodemailer = require('nodemailer');

const User = require('../models/user');

const items_per_page = 4;

var Publishable_Key = 'pk_test_51Mg50gSDe0wCTNeS1D9dLTi8fc1FcZxP6SRrAvmvz7rmPs9ZRqgG1cmSAgrAAYgp2FlWx8A4oO5r3PhQwasyJgyY00IGol43kz'
var Secret_Key = 'sk_test_51Mg50gSDe0wCTNeSaX9n85juh39jIu8T4ljlEX3iFULxsXRpWGSFixVZFAN4woEaRuPFFIdlg577kvszUCh0rMw500HVGWJQqk'
const stripe = require('stripe')(Secret_Key) 


// GET ADD CUSTOMER 
exports.getAddCustomer = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  res.render('service/add-customer', {
    path: '/add-customer',
    pageTitle: 'Add Customer',
    errorMessege: messege
  });
};


// POST ADD CUSTOMER 

exports.postAddCustomer = (req, res, next) => {
  const { role,name, email,password } = req.body;
  bcrypt
    .hash(password, 12)
    .then(hashedPassword => {
      const user = new User({
        role:role,
        name: name,
        email: email,
        password: hashedPassword,
      });
      return user.save();
    }).then(result=>{
      res.redirect('/userview/1');
    })
    .catch(err => {
      console.log(err);
    });
}




// GET USERVIEW

exports.getUserview = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  const roleId = req.params.roleId;
  const page = req.query.page;
 
  User.find()
    .skip((page-1)*items_per_page)
    .limit(items_per_page)
    .then(user => {
      if (user[0].role == 1) {
        console.log("other");
      }
      else {
        res.render('service/userview', {
          path: '/userview',
          pageTitle: 'userview',
          users: user,
          roleId: roleId, 
          errorMessege: messege
        })
      }
    })
}

exports.getDeleteUser = (req, res, next) => {
    User.findByIdAndDelete({ _id: req.params.id })
      .then(result => {
       res.redirect('/userview/1');
      })
      .catch(err => { console.log("ERROER :: ", err); })
  };

  exports.getEditUser = (req, res, next) => {
    const userId = req.params.id;
    let messege = req.flash('error');
    if (messege.length > 0) {
      messege = messege[0];
    } else {
      messege = null;
    }
    User.find({_id: userId})
    .then(result => {
        res.render('service/edit-user', {
          path: 'service/edit-user',
          pageTitle: 'Edit User',
          errorMessege: messege,
          users: result
        });
  })
}

exports.postUpdateUser =(req,res,next)=>{
  User.updateMany({_id: req.params.id},
  { $set: {
    role: req.body.role,
    name: req.body.name,
    email: req.body.email,
    password: req.body.password
  }}
  ).then(result=>{
    res.redirect('/userview/1');
  }).catch(err=>{
    console.log(err);
  })
}


//GET PAYMENT
exports.getPayment = (req, res, next) => {
  let messege = req.flash('error');
    if (messege.length > 0) {
      messege = messege[0];
    } else {
      messege = null;
    }
  res.render('service/payment', {
    path: '/payment',
    pageTitle: 'Payment',
    errorMessege:messege,
    key: Publishable_Key 
  })
}

//POST PAYMENT   
exports.postPayment = ("/create-checkout-session", async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [{
        
        price: 'price_1MiuI5SDe0wCTNeSS1jVWxdY',
        quantity: 1,
        
      }],
      mode: "payment",
      success_url: `http://localhost:3030/success`,
      cancel_url: `http://localhost:3030/cancel`,
    })
    res.redirect(303, session.url)
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

exports.getcancel = (res ,req , next)=> {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  res.render('cancel',{

      path: '/cancel',
      pageTitle: 'cancel',
      errorMessege:messege
     
  })
}

exports.getsuccess = (res ,req , next)=> {
  let messege = req.flash('error');
    if (messege.length > 0) {
      messege = messege[0];
    } else {
      messege = null;
    }
  res.render('service/success', {
    path: '/success',
    pageTitle: 'success',
    errorMessege:messege,
  })
}