const bcrypt = require('bcrypt');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const sendgridTransport = require('nodemailer-sendgrid-transport');
const {check} =require('express-validator');

const User = require('../models/user');
const Service = require('../models/service');

const items_per_page = 4;
// const router = require('../routes/service');

// GET ADD SERVICE

exports.getAddservice = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  const getRoleId = req.cookies.roleId;
  User.find()
  .then(result => {
      res.render('service/add-service', {
        path: 'service/add-service',
        pageTitle: 'add-service',
        roleId: getRoleId,
        errorMessege: messege,
        users: result
      });
  })
  .catch(err => {console.log("ERER : ", err);})
  // res.render('auth/add-service');
};

// POST ADD SERVICE

exports.postAddservice = (req, res, next) => {
  const { name, email, vehicleno, phoneno, pickupdate, dropdate } = req.body;
  const service = new Service({
    name: name,
    email: email,
    vehicleno: vehicleno,
    phoneno: phoneno,
    vehicleno: vehicleno,
    pickupdate: pickupdate,
    dropdate: dropdate
  })
  service.save()
  res.redirect('service-view');
}

exports.getServiceview = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  const page = req.query.page;
  Service.find()
  .skip((page-1)*items_per_page)
  .limit(items_per_page)
    .then(service => {
      res.render('service/service-view', {
        path: '/service-view',
        pageTitle: 'service-view',
        errorMessege: messege,
        services: service
      });
    })
  var transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "armanali.shaikh77@gmail.com",
      pass: "vdqrmojznlhtiibg"
    }
  });
  var mailOptions = {
     from: "armanali.shaikh77@gmail.com",
    to: "abc@gmail.com",
    // to: "armanali.shaikh77@gmail.com",
    subject: "Hello Service Add Mail,",
    text: "Thanks, Now Your Service is Added Successufully"
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log("Error: ", error)
    } else {
      console.log(info.response)
    }
  })

}


// DELETE service

exports.getDeleteService = (req, res, next) => {
  console.log("Service ID : ", req.params.id)
  Service.findByIdAndDelete({ _id: req.params.id })
    .then(result => {
      res.redirect('/service-view')
    })
    .catch(err => { 
      console.log("ERROER :: ", err); 
    })
};




exports.getEditService = (req, res, next) => {
  const serviceId = req.params.id;
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  Service.find({_id: serviceId})
  .then(result => {
      res.render('service/edit-service', {
        path: 'service/edit-service',
        pageTitle: 'Edit Service',
        errorMessege: messege,
        services: result
      });
})
}


exports.postUpdateService =(req,res,next)=>{
  Service.updateMany({_id: req.params.id},
  { $set: {
    name: req.body.name,
    email: req.body.email,
    vehicleno: req.body.vehicleno,
    phoneno: req.body.phoneno,
    pickupdate: req.body.pickupdate,
    dropdate: req.body.dropdate
  }}
  ).then(result=>{
    res.redirect('/service-view');
  }).catch(err=>{
    console.log(err);
  })

}
