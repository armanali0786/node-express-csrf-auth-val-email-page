const express = require('express');
const { check } = require('express-validator/check');
const serviceController = require('../controllers/service');
const router = express.Router();
const isAuth = require('../middleware/is-auth');

router.get('/add-service',isAuth, serviceController.getAddservice);
router.post('/add-service', serviceController.postAddservice);

router.get('/service-view',isAuth, serviceController.getServiceview);



router.get('/ser-delete/:id', serviceController.getDeleteService);



router.get('/edit-service/:id',isAuth, serviceController.getEditService);

router.post('/update-serv/:id',serviceController.postUpdateService);

module.exports = router;