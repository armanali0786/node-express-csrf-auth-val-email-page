const express = require('express');
const { check } = require('express-validator/check');
const customerController = require('../controllers/customer');
const router = express.Router();
const isAuth = require('../middleware/is-auth');

router.get('/add-customer',isAuth, customerController.getAddCustomer);
router.post('/add-customer', customerController.postAddCustomer);

router.get('/userview/:roleId',isAuth, customerController.getUserview);

router.get('/cus-delete/:id', customerController.getDeleteUser);

router.get('/edit/:id',isAuth, customerController.getEditUser);

router.post('/update/:id',customerController.postUpdateUser);

router.get('/payment',customerController.getPayment);

router.post('/payment',customerController.postPayment);

router.get('/success', customerController.getsuccess);
router.get('/cancel', customerController.getcancel);

module.exports = router;