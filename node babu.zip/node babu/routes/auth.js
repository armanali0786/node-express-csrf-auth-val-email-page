const express = require('express');
const { check } = require('express-validator/check');
const authController = require('../controllers/auth');
const isAuth = require('../middleware/is-auth');
const router = express.Router();

router.get('/login',authController.getLogin);
router.post('/login', authController.postLogin);

router.post('/logout', authController.postLogout);

router.get('/signup',authController.getSignup);
router.post('/signup', authController.postSignup);

router.get('/verifyOTP',isAuth, authController.getVerifyOTP);
router.post('/verifyOTP', authController.postVerifyOTP);


router.get('/welcome',isAuth, authController.getWelcome);
router.post('/welcome', authController.postWelcome);

router.get('/reset',isAuth, authController.getReset);
router.post('/reset', authController.postReset);

// router.get('/reset/:token', authController.getNewPassword);
// router.post('/new-password', authController.postNewPassword);


module.exports = router;